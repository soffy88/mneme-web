# @helios/oui

Helios OUI 框架：应用骨架（AppShell/SideBar/TopBar/AuthShell）+ 21 个标准页面 + 路由目录。构建于 @helios/blocks。

> ⚠️ 本仓源码从发布版 `@helios/oui@1.8.0` 的 sourcemap 还原，请先读 [`RECONSTRUCTION.md`](./RECONSTRUCTION.md)。

## 用法
```tsx
import { OAppProviders, OAppShell } from '@helios/oui';
import { OLoginPage, OSettingsPage } from '@helios/oui/pages';
import { allOUIPages } from '@helios/oui/routes';
import '@helios/oui/oui.css';
```
